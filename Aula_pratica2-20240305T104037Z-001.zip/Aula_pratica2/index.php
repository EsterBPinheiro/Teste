<?php
    $nome = "GOAT";
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Ester Pinheiro">
    <meta name="description" content="Aula pratica sobre performance">
    <title>Aula Prática 2</title>
</head>
<body>
    <header>
        <a href="atexto">TEXTO</a></br>
        <a href="aimagem">IMAGEM</a>
        <hr>
    </header>
    <main>
        <section id="texto">
            <?php echo "<h1>Bem-Vindo ".$nome."!</h1>";?>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
                Mollitia, eos a sapiente ex reiciendis inventore nihil eum, 
                saepe incidunt dolorem odit repellendus, ad quo nemo dolor. 
                Enim at ut fuga.</p>
        </section>
        <section id="imagem">
            <figure>
                <img src=".\poring.jfif" alt="Uma figura de um poring">
                <figcaption>Um Poring</figcaption>
            </figure>
        </section>
    </main>
    <footer>
        <hr>
        <address>
            <a href="mailto:abelloni@aluni.usp.br">E-mail</a>
        </address>
            <i class="fa fa-copyright" aria-hidden="true">Códigos de alta performance - web - UNG</i>

    </footer>
    
</body>
</html>